package com.thirtytwo.steps

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class StepsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val prefs = PrefsManager(this)
        val wasEnabled = prefs.enabled
        prefs.enabled = !prefs.enabled

        // Start or stop the AudioService based on enabled state
        val serviceIntent = Intent(this, AudioService::class.java)
        if (prefs.enabled) {
            // Enable requested - start the service
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            // Disable requested - stop the service
            stopService(serviceIntent)
        }

        // Reset headphone auto-switch profile tracking when disabling
        if (!prefs.enabled) {
            prefs.profileBeforeAutoSwitch = null
        }

        updateTile()
    }

    private fun updateTile() {
        val prefs = PrefsManager(this)
        val tile = qsTile ?: return
        tile.state = if (prefs.enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "32steps"
        tile.subtitle = if (prefs.enabled) "${prefs.totalSteps} steps" else "Off"
        tile.updateTile()
    }
}
